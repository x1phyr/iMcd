#!/bin/bash
set -e

# ============================================
# 配置区域 - 根据你的环境修改
# ============================================
SERVER_USER="root"
SERVER_HOST="your-server-ip"
SERVER_PATH="/opt/imcd"
# ============================================

echo "🔗 连接服务器并部署..."

ssh ${SERVER_USER}@${SERVER_HOST} << EOF
set -e
cd ${SERVER_PATH}

echo "📥 加载镜像..."
docker load -i imcd-images.tar

echo "🔄 重启服务..."
docker compose down 2>/dev/null || true
docker compose up -d

echo "⏳ 等待服务启动..."
sleep 5

echo "📊 服务状态:"
docker compose ps

echo "✅ 部署完成！"
EOF
