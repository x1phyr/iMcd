#!/bin/bash
set -e

# ============================================
# 配置区域 - 根据你的环境修改
# ============================================
SERVER_USER="root"
SERVER_HOST="your-server-ip"
SERVER_PATH="/opt/imcd"
# ============================================

cd "$(dirname "$0")/.."

echo "🔨 构建 amd64 镜像..."
docker build --platform linux/amd64 -t imcd-backend:latest ./backend
docker build --platform linux/amd64 -t imcd-frontend:latest --build-arg VITE_API_URL=/api ./frontend

echo "📦 导出镜像..."
docker save imcd-backend:latest imcd-frontend:latest -o imcd-images.tar

echo "🚀 上传到服务器..."
ssh ${SERVER_USER}@${SERVER_HOST} "mkdir -p ${SERVER_PATH}"
scp imcd-images.tar docker-compose.yml ${SERVER_USER}@${SERVER_HOST}:${SERVER_PATH}/

echo "✅ 完成！运行 ./scripts/deploy.sh 启动服务"
