#!/bin/bash

# ============================================
# 配置区域 - 根据你的环境修改
# ============================================
SERVER_USER="root"
SERVER_HOST="your-server-ip"
SERVER_PATH="/opt/imcd"
# ============================================

ssh ${SERVER_USER}@${SERVER_HOST} "cd ${SERVER_PATH} && docker compose logs -f"
